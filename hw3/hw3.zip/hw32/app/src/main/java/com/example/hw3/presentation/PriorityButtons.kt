package com.example.hw3.presentation

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.hw3.data.Priority

@Composable
fun PriorityButtons(
    selectedPriority: Priority,
    onPrioritySelected: (Priority) -> Unit
) {
    Row {
        Button(
            onClick = { onPrioritySelected(Priority.LOW) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedPriority == Priority.LOW)
                    Color.Green
                else
                    MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedPriority == Priority.LOW)
                    Color.White
                else
                    MaterialTheme.colorScheme.onSurface
            )
        ) {
            Text("Низкий")
        }

        Spacer(modifier = Modifier.width(8.dp))

        Button(
            onClick = { onPrioritySelected(Priority.MEDIUM) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedPriority == Priority.MEDIUM)
                    Color(0xFFFFA500)
                else
                    MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedPriority == Priority.MEDIUM)
                    Color.White
                else
                    MaterialTheme.colorScheme.onSurface
            )
        ) {
            Text("Средний")
        }

        Spacer(modifier = Modifier.width(8.dp))

        Button(
            onClick = { onPrioritySelected(Priority.HIGH) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedPriority == Priority.HIGH)
                    Color.Red
                else
                    MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedPriority == Priority.HIGH)
                    Color.White
                else
                    MaterialTheme.colorScheme.onSurface
            )
        ) {
            Text("Высокий")
        }
    }
}