package com.example.hw3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw3.data.Priority
import com.example.hw3.data.Task
import com.example.hw3.data.TaskRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.util.Date

class TaskViewModel(
    private val repository: TaskRepository = TaskRepository()
) : ViewModel() {

    val tasks: StateFlow<List<Task>> = repository.tasks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val sortedByPriorityTasks: StateFlow<List<Task>> = repository.tasks
        .map { tasks ->
            val priorityOrder = mapOf(Priority.HIGH to 0, Priority.MEDIUM to 1, Priority.LOW to 2)
            tasks.sortedBy { priorityOrder[it.priority] }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addTask(
        title: String,
        description: String,
        priority: Priority,
        isFlagged: Boolean,
        dueDate: Date?
    ) {
        if (title.isBlank()) return

        val task = Task(
            title = title,
            description = description,
            priority = priority,
            isFlagged = isFlagged,
            dueDate = dueDate
        )
        repository.addTask(task)
    }

    fun toggleTaskCompletion(taskId: String) {
        repository.toggleTaskCompletion(taskId)
    }
}