package com.example.hw3.data

data class NewsArticle(
    val title: String,
    val description: String,
    val source: String,
    val publishedDate: String
)