package com.example.hw3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw3.data.NewsArticle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface NytApiService {
    @GET("articlesearch.json")
    suspend fun getNews(
        @Query("api-key") apiKey: String,
        @Query("sort") sort: String = "newest"
    ): NytResponse
}

data class NytResponse(
    val response: NytDocs
)

data class NytDocs(
    val docs: List<NytArticle>
)

data class NytArticle(
    val headline: Headline,
    val abstract: String,
    val byline: Byline?,
    val pub_date: String
)

data class Headline(
    val main: String
)

data class Byline(
    val original: String?
)

class NewsViewModel : ViewModel() {

    private val _newsState = MutableStateFlow<NewsState>(NewsState.Loading)
    val newsState: StateFlow<NewsState> = _newsState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val apiKey = "Z4aAZVoaGGFRC1wIbm9suWnq0gtniI8A9Tj5A6d78L0h0KWD"

    private val apiService = Retrofit.Builder()
        .baseUrl("https://api.nytimes.com/svc/search/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(NytApiService::class.java)

    init {
        loadNews()
        startPeriodicRefresh()
    }

    fun loadNews() {
        viewModelScope.launch {
            _newsState.value = NewsState.Loading

            try {
                val response = apiService.getNews(apiKey = apiKey)

                val articles = response.response.docs.map { doc ->
                    NewsArticle(
                        title = doc.headline.main,
                        description = doc.abstract.ifEmpty { "Нет описания" },
                        source = doc.byline?.original?.removePrefix("By ") ?: "NY Times",
                        publishedDate = doc.pub_date.substringBefore("T")
                    )
                }

                _newsState.value = if (articles.isEmpty()) {
                    NewsState.Empty
                } else {
                    NewsState.Success(articles)
                }
            } catch (e: Exception) {
                _newsState.value = NewsState.Error(e.message ?: "Ошибка загрузки")
            }
        }
    }

    private fun startPeriodicRefresh() {
        viewModelScope.launch {
            while (true) {
                delay(120_000)
                _isRefreshing.value = true
                loadNews()
                _isRefreshing.value = false
            }
        }
    }

    fun refreshManually() {
        viewModelScope.launch {
            _isRefreshing.value = true
            loadNews()
            _isRefreshing.value = false
        }
    }
}

sealed class NewsState {
    object Loading : NewsState()
    object Empty : NewsState()
    data class Success(val articles: List<NewsArticle>) : NewsState()
    data class Error(val message: String) : NewsState()
}