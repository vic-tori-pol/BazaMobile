package com.example.hw3.data

import java.util.Date
import java.util.UUID

enum class Priority {
    LOW, MEDIUM, HIGH
}

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val priority: Priority = Priority.MEDIUM,
    val isFlagged: Boolean = false,
    val dueDate: Date? = null,
    val isCompleted: Boolean = false,
    val createdAt: Date = Date()
)