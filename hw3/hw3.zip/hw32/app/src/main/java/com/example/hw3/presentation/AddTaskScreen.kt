package com.example.hw3.presentation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.hw3.data.Priority
import com.example.hw3.viewmodel.TaskViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskScreen(
    viewModel: TaskViewModel,
    onNavigateBack: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf(Priority.MEDIUM) }
    var isFlagged by remember { mutableStateOf(false) }
    var hasDueDate by remember { mutableStateOf(false) }
    var dueDate by remember { mutableStateOf<Date?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Новая задача") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Text("Отмена")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название задачи *") },
                modifier = Modifier.fillMaxWidth(),
                isError = title.isBlank()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Описание (необязательно)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Text("Приоритет", style = MaterialTheme.typography.titleMedium)
            PriorityButtons(
                selectedPriority = selectedPriority,
                onPrioritySelected = { selectedPriority = it }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Отметить флагом")
                Switch(
                    checked = isFlagged,
                    onCheckedChange = { isFlagged = it }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Установить дату завершения")
                Switch(
                    checked = hasDueDate,
                    onCheckedChange = { hasDueDate = it }
                )
            }

            if (hasDueDate) {
                OutlinedTextField(
                    value = dueDate?.let { dateFormat.format(it) } ?: "",
                    onValueChange = {},
                    label = { Text("Дата завершения") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Text("Выбрать")
                        }
                    }
                )
            }

            if (showDatePicker) {
                DateTimePickerDialog(
                    onDateSelected = { selectedDate ->
                        dueDate = selectedDate
                        showDatePicker = false
                    },
                    onDismiss = { showDatePicker = false }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        viewModel.addTask(
                            title = title,
                            description = description,
                            priority = selectedPriority,
                            isFlagged = isFlagged,
                            dueDate = if (hasDueDate) dueDate else null
                        )
                        onNavigateBack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = title.isNotBlank()
            ) {
                Text("Сохранить")
            }
        }
    }
}

@Composable
fun DateTimePickerDialog(
    onDateSelected: (Date) -> Unit,
    onDismiss: () -> Unit
) {
    val calendar = Calendar.getInstance()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(400.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Выберите дату и время", style = MaterialTheme.typography.titleLarge)

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onDateSelected(calendar.time)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Выбрать текущую дату и время")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = {
                            calendar.add(Calendar.DAY_OF_YEAR, 1)
                            onDateSelected(calendar.time)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Завтра")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            calendar.add(Calendar.DAY_OF_YEAR, 7)
                            onDateSelected(calendar.time)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Через неделю")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = onDismiss) {
                    Text("Отмена")
                }
            }
        }
    }
}