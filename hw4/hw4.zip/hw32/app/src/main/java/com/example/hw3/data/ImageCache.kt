package com.example.hw3.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class ImageCache(private val context: Context) {

    private val cacheDir = File(context.cacheDir, "image_cache")
    private val maxCacheSizeMB = 50L

    init {
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }
        cleanOldCache()
    }

    suspend fun getImage(url: String): Bitmap? {
        return withContext(Dispatchers.IO) {
            val file = getFile(url)
            if (file.exists()) {
                BitmapFactory.decodeFile(file.absolutePath)
            } else null
        }
    }

    suspend fun saveImage(url: String, bitmap: Bitmap) {
        withContext(Dispatchers.IO) {
            try {
                val file = getFile(url)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
                checkCacheSize()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun downloadAndCacheImage(url: String): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                getImage(url)?.let { return@withContext it }
                val client = OkHttpClient()
                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    response.body?.byteStream()?.use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                        if (bitmap != null) {
                            saveImage(url, bitmap)
                            return@withContext bitmap
                        }
                    }
                }
                null
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    private fun getFile(url: String): File {
        val filename = MessageDigest.getInstance("MD5")
            .digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) } + ".jpg"
        return File(cacheDir, filename)
    }

    private fun cleanOldCache() {
        try {
            val cutoffTime = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L)
            cacheDir.listFiles()?.forEach { file ->
                if (file.lastModified() < cutoffTime) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun checkCacheSize() {
        var totalSize = 0L
        val files = cacheDir.listFiles() ?: return
        files.forEach { totalSize += it.length() }
        if (totalSize > maxCacheSizeMB * 1024 * 1024) {
            files
                .sortedBy { it.lastModified() }
                .take(files.size / 2)
                .forEach { it.delete() }
        }
    }
}