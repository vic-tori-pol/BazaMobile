package com.example.hw3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.hw3.data.NewsArticle
import com.example.hw3.data.NewsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NewsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NewsRepository(application)

    private val _newsState = MutableStateFlow<NewsState>(NewsState.Loading)
    val newsState: StateFlow<NewsState> = _newsState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        loadCachedNews()
        loadNews()
        startPeriodicRefresh()
    }

    private fun loadCachedNews() {
        viewModelScope.launch {
            repository.getCachedNewsStream().collect { cachedArticles ->
                if (cachedArticles.isNotEmpty() && _newsState.value is NewsState.Loading) {
                    _newsState.value = NewsState.Success(
                        articles = cachedArticles,
                        isFromCache = true
                    )
                }
            }
        }
    }

    fun loadNews() {
        viewModelScope.launch {
            try {
                val articles = repository.fetchAndCacheNews()
                if (articles != null && articles.isNotEmpty()) {
                    _newsState.value = NewsState.Success(
                        articles = articles,
                        isFromCache = false
                    )
                } else if (_newsState.value is NewsState.Loading) {
                    _newsState.value = NewsState.Error("Нет подключения к интернету")
                }
            } catch (e: Exception) {
                if (_newsState.value is NewsState.Loading) {
                    _newsState.value = NewsState.Error(e.message ?: "Ошибка загрузки")
                }
            }
        }
    }

    private fun startPeriodicRefresh() {
        viewModelScope.launch {
            while (true) {
                delay(120_000)
                _isRefreshing.value = true
                loadNews()
                repository.cleanOldCache()
                _isRefreshing.value = false
            }
        }
    }

    fun refreshManually() {
        viewModelScope.launch {
            _isRefreshing.value = true
            loadNews()
            _isRefreshing.value = false
        }
    }
}

sealed class NewsState {
    object Loading : NewsState()
    object Empty : NewsState()
    data class Success(
        val articles: List<NewsArticle>,
        val isFromCache: Boolean = false
    ) : NewsState()
    data class Error(val message: String) : NewsState()
}