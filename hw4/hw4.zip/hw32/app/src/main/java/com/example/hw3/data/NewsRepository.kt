package com.example.hw3.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface TopStoriesApiService {
    @GET("{section}.json")
    suspend fun getTopStories(
        @Path("section") section: String = "home",
        @Query("api-key") apiKey: String
    ): TopStoriesResponse
}

data class TopStoriesResponse(
    val results: List<TopStory>
)

data class TopStory(
    val title: String,
    val abstract: String,
    val byline: String,
    val published_date: String,
    val multimedia: List<Multimedia>? = null
)

data class Multimedia(
    val url: String,
    val format: String,
    val type: String
)

class NewsRepository(private val context: Context) {

    private val database = NewsDatabase.getDatabase(context)
    private val dao = database.newsDao()

    private val apiKey = "PZkwPNiC4CGEeR2hy18GH7Wpa9aXzxsQBQmTrrK02tuO9jQA"

    private val apiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.nytimes.com/svc/topstories/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TopStoriesApiService::class.java)
    }

    private fun getImageUrl(multimedia: List<Multimedia>?): String? {
        if (multimedia.isNullOrEmpty()) return null

        val image = multimedia.firstOrNull { it.format == "mediumThreeByTwo210" }
            ?: multimedia.firstOrNull { it.format == "thumbLarge" }
            ?: multimedia.firstOrNull { it.type == "image" }

        return image?.url
    }

    fun getCachedNewsStream(): Flow<List<NewsArticle>> {
        return dao.getAllNews().map { cachedArticles ->
            cachedArticles.map { cached ->
                NewsArticle(
                    title = cached.title,
                    description = cached.description,
                    source = cached.source,
                    publishedDate = cached.publishedDate,
                    imageUrl = cached.imageUrl
                )
            }
        }
    }

    suspend fun fetchAndCacheNews(): List<NewsArticle>? {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.getTopStories(apiKey = apiKey)

                val articles = response.results.map { story ->
                    NewsArticle(
                        title = story.title,
                        description = story.abstract.ifEmpty { "Нет описания" },
                        source = story.byline.ifEmpty { "NY Times" },
                        publishedDate = story.published_date.substringBefore("T"),
                        imageUrl = getImageUrl(story.multimedia)
                    )
                }.take(50)

                val cachedArticles = articles.map { article ->
                    CachedNewsArticle(
                        title = article.title,
                        description = article.description,
                        source = article.source,
                        publishedDate = article.publishedDate,
                        imageUrl = article.imageUrl
                    )
                }

                val currentCount = dao.getCount()
                if (currentCount + cachedArticles.size > CachePolicy.MAX_CACHE_SIZE) {
                    dao.deleteOlderThan(System.currentTimeMillis() - CachePolicy.CACHE_VALIDITY_DURATION_MS)
                }

                dao.insertAll(cachedArticles)
                articles

            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun cleanOldCache() {
        withContext(Dispatchers.IO) {
            dao.deleteOlderThan(System.currentTimeMillis() - CachePolicy.CACHE_VALIDITY_DURATION_MS)
        }
    }
}