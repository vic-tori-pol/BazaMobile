package com.example.hw3.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_news")
data class CachedNewsArticle(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val source: String,
    val publishedDate: String,
    val imageUrl: String? = null,
    val cachedAt: Long = System.currentTimeMillis()
)