package com.example.hw3.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    @Query("SELECT * FROM cached_news ORDER BY publishedDate DESC")
    fun getAllNews(): Flow<List<CachedNewsArticle>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(articles: List<CachedNewsArticle>)

    @Query("DELETE FROM cached_news WHERE cachedAt < :olderThan")
    suspend fun deleteOlderThan(olderThan: Long)

    @Query("SELECT COUNT(*) FROM cached_news")
    suspend fun getCount(): Int
}